package Hamburgueseria;

public class Silla {
	public Cliente cliente;
	public boolean ocupada;
	public boolean atendida;
	
	public Silla() {
		this.ocupada = false;
		this.atendida = false;
	}
}
