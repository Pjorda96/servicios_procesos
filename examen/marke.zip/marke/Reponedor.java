package marke;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingDeque;

public class Reponedor implements Runnable{
	private BlockingQueue<Integer> estanteria;
	int stock;

	public Reponedor(int stock, BlockingQueue<Integer> estanteria) {
		this.estanteria = new LinkedBlockingDeque<Integer>();
		this.estanteria = estanteria;

		this.stock = stock;
	}

	@Override
	public void run() {
		while(true) {
			try {
				if(estanteria.size() > 2) {
					Thread.sleep(100);
				} else {
					if (this.stock > 0 && this.stock < 5) {
						for(int i=0; i < stock; i++) {
							this.estanteria.put(i);
						}

						System.out.println("Estanteria vacia");
						this.stock = 0;
					} else if (this.stock > 0) {
						for(int i=0; i < 5; i++) {
							this.estanteria.put(i);
						}

						System.out.println("Llenando estanteria");
						this.stock = this.stock - 5;
					}

					Thread.sleep(1000);
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}
