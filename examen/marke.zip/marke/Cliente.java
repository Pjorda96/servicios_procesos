package marke;

public class Cliente implements Runnable{
	
	Tienda tienda;
	
	public Cliente(Tienda t) {this.tienda = t;}

	@Override
	public void run() {
		double tipoProducto = Math.random();

		try {
			if(tipoProducto < 0.33) {
				tienda.est_televisor.take();
				System.out.println("Quitando televisor");
			} else if (tipoProducto > 0.66) {
				tienda.est_portatil.take();
				System.out.println("Quitando portatil");
			} else {
				tienda.est_movil.take();
				System.out.println("Quitando movil");
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
