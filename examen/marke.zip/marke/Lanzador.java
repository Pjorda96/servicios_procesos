package marke;

public class Lanzador {
	
	public static void main(String[] args) throws InterruptedException {
		int nTelevisiores = Integer.parseInt(args[0]);
		int nPortatiles = Integer.parseInt(args[1]);
		int nMoviles = Integer.parseInt(args[2]);

		Tienda tienda = new Tienda(nTelevisiores, nPortatiles, nMoviles);

		while(true) {
			Cliente cliente = new Cliente(tienda);
			Thread threadCliente = new Thread(cliente);
			threadCliente.start();
			Thread.sleep(200);
		}
	}
}
