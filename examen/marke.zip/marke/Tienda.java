package marke;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingDeque;

public class Tienda {
    int televisor;
    int portatil;
    int movil;

    public static BlockingQueue<Integer> est_televisor;
    public static BlockingQueue<Integer> est_portatil;
    public static BlockingQueue<Integer> est_movil;

    public Tienda(int televisor, int portatil, int movil) throws InterruptedException {
        this.televisor = televisor;
        this.portatil = portatil;
        this.movil = movil;

        this.est_televisor = new LinkedBlockingDeque<Integer>();
        this.est_portatil = new LinkedBlockingDeque<Integer>();
        this.est_movil = new LinkedBlockingDeque<Integer>();

        for(int i=0; i < 10; i++) {
            this.est_televisor.put(i);
            this.est_portatil.put(i);
            this.est_movil.put(i);
        }

        System.out.println("Empezando");

        Reponedor reponedor1 = new Reponedor(televisor, est_televisor);
        Reponedor reponedor2 = new Reponedor(portatil, est_portatil);
        Reponedor reponedor3 = new Reponedor(movil, est_movil);

        Thread threadReponedor1 = new Thread(reponedor1);
        Thread threadReponedor2 = new Thread(reponedor2);
        Thread threadReponedor3 = new Thread(reponedor3);

        threadReponedor1.start();
        threadReponedor2.start();
        threadReponedor3.start();
    }
}
