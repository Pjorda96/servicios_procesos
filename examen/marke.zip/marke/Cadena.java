package marke;

import java.io.IOException;

public class Cadena {
	
	public static void launch(String nTelevisores, String nPortatiles, String nMovil) throws IOException {
		ProcessBuilder pb = new ProcessBuilder("java", "-cp", "bin", "examen.Lanzador", nTelevisores, nPortatiles, nMovil);
		pb.start();
	}

	public static void main(String[] args) throws IOException {
		String nTelevisores1 = args[0];
		String nPortatiles1 = args[1];
		String nMoviles1 = args[2];

		launch(nTelevisores1, nPortatiles1, nMoviles1);

		String nTelevisores2 = args[3];
		String nPortatiles2 = args[4];
		String nMoviles2 = args[5];

		launch(nTelevisores2, nPortatiles2, nMoviles2);
	}
}
